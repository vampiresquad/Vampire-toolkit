
# Vampire Toolkit

**OSINT Toolkit for Ethical Hackers**

Created by: Muhammad Shourov  
GitHub: https://github.com/vampiresquad

## Features
- Terminal Banner with Color
- Ethical Hacker Identity
- Easy to Use Bash Script

## Usage
1. Unzip the file.
2. Run `setup.sh` using Termux or Linux terminal:

```bash
chmod +x setup.sh
./setup.sh
```

## License
This tool is created for educational purposes only.
