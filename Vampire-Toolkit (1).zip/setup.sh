#!/bin/bash

RED='\033[0;31m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

echo -e "${RED} __     ______  _    _   _____ _____  _      ____   _____ ____  _  __"
echo -e "${RED} \ \   / / __ \| |  | | |_   _|  __ \| |    / __ \ / ____/ __ \| |/ /"
echo -e "${RED}  \ \_/ / |  | | |  | |   | | | |__) | |   | |  | | (___| |  | | ' / "
echo -e "${RED}   \   /| |  | | |  | |   | | |  ___/| |   | |  | |\___ \ |  | |  <  "
echo -e "${RED}    | | | |__| | |__| |  _| |_| |    | |___| |__| |____) | |__| | . \ "
echo -e "${RED}    |_|  \____/ \____/  |_____|_|    |______\____/|_____/ \____|_|\_\\${NC}"

echo -e "${CYAN}"
echo "           [ Vampire Toolkit - OSINT Arsenal for Ethical Hackers ]"
echo -e "${WHITE}                      Created by: Muhammad Shourov${NC}"
echo ""

echo -e "${CYAN}[+] Toolkit Setup Complete. Ready to Hack with Ethics!${NC}"
