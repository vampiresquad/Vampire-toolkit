#!/bin/bash

# Colors
green="\e[1;32m"
reset="\e[0m"

# Banner
echo -e "${green}"
echo " __     ______  _    _   _____ _____  _      ____   _____ ____  _  __"
echo " \ \   / / __ \| |  | | |_   _|  __ \| |    / __ \ / ____/ __ \| |/ /"
echo "  \ \_/ / |  | | |  | |   | | | |__) | |   | |  | | (___| |  | | ' / "
echo "   \   /| |  | | |  | |   | | |  ___/| |   | |  | |\___ \ |  | |  <  "
echo "    | | | |__| | |__| |  _| |_| |    | |___| |__| |____) | |__| | . \"
echo "    |_|  \____/ \____/  |_____|_|    |______\____/|_____/ \____|_|\_\"
echo -e "${reset}"

echo -e " [ Vampire Toolkit - OSINT Arsenal for Ethical Hackers ]"
echo -e " Created by: Muhammad Shourov"
echo ""

# Menu
echo -e "${green}[1] IP Tracker"
echo -e "[2] Phone Number Info"
echo -e "[3] Email Breach Checker${reset}"
echo ""
read -p "Choose an option: " choice

if [ "$choice" == "1" ]; then
  bash tools/iptracker.sh
elif [ "$choice" == "2" ]; then
  bash tools/phoneinfo.sh
elif [ "$choice" == "3" ]; then
  bash tools/emailcheck.sh
else
  echo "Invalid option!"
fi
