spiderfoot - placeholder for tool files.
