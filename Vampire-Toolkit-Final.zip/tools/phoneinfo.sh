#!/bin/bash
read -p "Enter Phone Number (with country code): " number
curl -s "https://api.apilayer.com/number_verification/validate?number=$number" -H "apikey: YOUR_API_KEY" | jq
