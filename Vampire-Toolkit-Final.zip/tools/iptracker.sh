#!/bin/bash
read -p "Enter IP Address: " ip
curl -s http://ip-api.com/json/$ip | jq
