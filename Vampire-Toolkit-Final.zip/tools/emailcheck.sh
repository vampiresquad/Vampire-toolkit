#!/bin/bash
read -p "Enter Email Address: " email
curl -s "https://haveibeenpwned.com/api/v3/breachedaccount/$email" -H "hibp-api-key: YOUR_API_KEY" | jq
